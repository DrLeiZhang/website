% This is the L2 regularization code of SEM for interferenes recognition
clear all 
clc
close all
%% load data
load('data_cho_new.mat');data_cho_new=data_cho_new';
load('data_ben_new.mat');data_ben_new=data_ben_new';
load('data_jiaben_new.mat');data_jiaben_new=data_jiaben_new';
load('data_co_new.mat');data_co_new=data_co_new';
load('data_no2_new.mat');data_no2_new=data_no2_new';
load('data_an_new.mat');data_an_new=data_an_new';
load('jiujing.mat');data_jiujing=jiujing';

data_cho_new(:,3)=[];data_ben_new(:,3)=[];data_jiaben_new(:,3)=[];data_co_new(:,3)=[];% delete GSBT11 sensor
data_no2_new(:,3)=[];data_an_new(:,3)=[];data_jiujing(:,3)=[];
data_cho_new(:,5)=[];data_ben_new(:,5)=[];data_jiaben_new(:,5)=[];data_co_new(:,5)=[];% delete Oxygen sensor
data_no2_new(:,5)=[];data_an_new(:,5)=[];data_jiujing(:,5)=[];

u=5;  %select one fifth of the data for testing
test_Target=[data_cho_new(1:u:188,:);data_ben_new(1:u:72,:);data_jiaben_new(1:u:66,:);data_co_new(1:u:58,:);data_no2_new(1:u:38,:);data_an_new(1:u:60,:)];
data_cho_new(1:u:size(data_cho_new,1),:)=[]; data_ben_new(1:u:size(data_ben_new,1),:)=[];data_jiaben_new(1:u:size(data_jiaben_new,1),:)=[];
data_co_new(1:u:size(data_co_new,1),:)=[];data_no2_new(1:u:size(data_no2_new,1),:)=[];data_an_new(1:u:size(data_an_new,1),:)=[];

%dividing the training data into two parts
data_cho_new1=data_cho_new(1:2:size(data_cho_new,1),:);data_ben_new1=data_ben_new(1:2:size(data_ben_new,1),:);data_jiaben_new1=data_jiaben_new(1:2:size(data_jiaben_new,1),:);
data_co_new1=data_co_new(1:2:size(data_co_new,1),:);data_no2_new1=data_no2_new(1:2:size(data_no2_new,1),:);data_an_new1=data_an_new(1:2:size(data_an_new,1),:);

data_cho_new2=data_cho_new(2:2:size(data_cho_new,1),:);data_ben_new2=data_ben_new(2:2:size(data_ben_new,1),:);data_jiaben_new2=data_jiaben_new(2:2:size(data_jiaben_new,1),:);
data_co_new2=data_co_new(2:2:size(data_co_new,1),:);data_no2_new2=data_no2_new(2:2:size(data_no2_new,1),:);data_an_new2=data_an_new(2:2:size(data_an_new,1),:);


%randomly select w samples per class to find alpha
% w=10;
% data_S=[rand(w,size(data_cho_new1,2)); rand(w,size(data_ben_new1,2)); rand(w,size(data_jiaben_new1,2)); rand(w,size(data_co_new1,2)); rand(w,size(data_no2_new1,2)); rand(w,size(data_an_new1,2))]; 
data_S=[data_cho_new1;data_ben_new1;data_jiaben_new1;data_co_new1;data_no2_new1;data_an_new1];
%randomly select v samples per class to find T
 v=15;
 data_Target=[rand(v,size(data_cho_new2,2)); rand(v,size(data_ben_new2,2)); rand(v,size(data_jiaben_new2,2)); rand(v,size(data_co_new2,2)); rand(v,size(data_no2_new2,2)); rand(v,size(data_an_new2,2))]; 
% data_Target=[data_cho_new2;data_ben_new2;data_jiaben_new2;data_co_new2;data_no2_new2;data_an_new2];

total_jiujing=data_jiujing;
data_jiujing=total_jiujing(1:2:size(total_jiujing,1),:);
test_jiujing=total_jiujing(2:2:size(total_jiujing,1),:);

sensor1=3;
sensor2=4;
sensor3=5;
sensor4=6;
data_S=data_S';
data_Target=data_Target';
data_jiujing=data_jiujing';
test_Target=test_Target';
test_jiujing=test_jiujing';
lambda=10^(9);   % regularization parameter

%% compute alpha
alpha=pinv(data_S'*data_S+lambda*eye )*data_S'*data_S;
data_S1=data_S*alpha;
%% target samples to find T
wucha_Target(size(data_Target,2),1)=0;
for i=1:size(data_Target,2)
    for j=1:size(alpha,1)
    wucha_T(i,j)=(data_Target(:,i)-data_S*alpha(:,j))'*(data_Target(:,i)-data_S*alpha(:,j));
    wucha_Target(i,:)=wucha_T(i,j)+wucha_Target(i,:);
    end
end
wucha_Target=wucha_Target/size(data_Target,2);
%% alcohol samples to find T
wucha_jiujing(size(data_jiujing,2),1)=0;
for i=1:size(data_jiujing,2)
    for j=1:size(alpha,1)
    wucha_jiu(i,j)=(data_jiujing(:,i)-data_S*alpha(:,j))'*(data_jiujing(:,i)-data_S*alpha(:,j));
    wucha_jiujing(i,:)=wucha_jiu(i,j)+wucha_jiujing(i,:);
    end
end
wucha_jiujing=wucha_jiujing/size(data_S,2);

%% find the optimal T
counter=0;
for T= min(wucha_Target):0.0005:max(wucha_jiujing)
    counter=counter+1;
    count_Target= sum(sum(wucha_Target<T));
    count_jiujing=sum(sum(wucha_jiujing>T));
    rate_Target=count_Target/size(data_Target,2);
    rate_jiujing=count_jiujing/size(data_jiujing,2);
    result(counter,1)=T;
    result(counter,2)=rate_Target;
    result(counter,3)=rate_jiujing;
    result(counter,4)=rate_Target+rate_jiujing;
end
[max,index]=max(result(:,4));
T_MAX=result(index,1)
rate_Target=result(index,2)
rate_jiujing=result(index,3)
rate_total=max

%% testing target 
T=T_MAX;
wucha1_Target(size(test_Target,2),1)=0;
for i=1:size(test_Target,2)
    for j=1:size(alpha,1)
    wucha_Tar(i,j)=(test_Target(:,i)-data_S*alpha(:,j))'*(test_Target(:,i)-data_S*alpha(:,j));
    wucha1_Target(i,:)=wucha_Tar(i,j)+wucha1_Target(i,:);
    end
end
wucha1_Target=wucha1_Target/size(data_S,2);
count_Target=sum(sum(wucha1_Target<T));
test_rate_Target=count_Target/size(test_Target,2)
%% testing alcohol
wucha1_jiujing(size(test_jiujing,2),1)=0;
for i=1:size(test_jiujing,2)
    for j=1:size(alpha,1)
    wucha_jiu(i,j)=(test_jiujing(:,i)-data_S*alpha(:,j))'*(test_jiujing(:,i)-data_S*alpha(:,j));
    wucha1_jiujing(i,:)=wucha_jiu(i,j)+wucha1_jiujing(i,:);
    end
end
wucha1_jiujing=wucha1_jiujing/size(data_S,2);
count_jiujing=sum(sum(wucha1_jiujing>T));
test_rate_jiujing=count_jiujing/size(test_jiujing,2)


