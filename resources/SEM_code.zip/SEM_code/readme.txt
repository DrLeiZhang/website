============SEM and SEELM demo===================

This code is from the following paper,

L. Zhang, P. Deng, "Abnormal Odor Detection in Electronic Nose via Self-expression Inspired Extreme Learning Machine," IEEE Transactions on System, Man, and Cybernetics: Systems, vol. PP, no. 99, pp. 1-11, 2017.

Please kindly cite this paper if you would like to use the code.

========================================================================
In the file, there are four files. 
One is dataset, the other three are SEM(l1/l2-norm regularizer) and SEELM. 

You can run the "demo.m" code for your reference.


=======================================================================
Please feel free to contact dengpl@cqu.edu.cn if there is any problem

Enjoy it!



