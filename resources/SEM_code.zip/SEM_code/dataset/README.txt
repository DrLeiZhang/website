===========Dataset illustration===================

There are totally six kinds of targer odors and an abnormal odor of alcohol

============================================================================
Target odor:
data_an_new is ammonia,data_ben_new is benzene,data_cho_new is formaldehyde, 

data_co_new is carbon monoxide,
data_jiaben_new is toluene, and data_no2_new is nitrogen dioxide



abnormal odor: jiujing is Alcohol

