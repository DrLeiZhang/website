% This is the ELM way of SEM for interferenes recognition
clear all 
clc
close all
%%  load data
load('data_cho_new.mat');data_cho_new=data_cho_new';
load('data_ben_new.mat');data_ben_new=data_ben_new';
load('data_jiaben_new.mat');data_jiaben_new=data_jiaben_new';
load('data_co_new.mat');data_co_new=data_co_new';
load('data_no2_new.mat');data_no2_new=data_no2_new';
load('data_an_new.mat');data_an_new=data_an_new';
load('jiujing.mat');data_jiujing=jiujing';

data_cho_new(:,3)=[];data_ben_new(:,3)=[];data_jiaben_new(:,3)=[];data_co_new(:,3)=[];% ɾȥGSBT11
data_no2_new(:,3)=[];data_an_new(:,3)=[];data_jiujing(:,3)=[];
data_cho_new(:,5)=[];data_ben_new(:,5)=[];data_jiaben_new(:,5)=[];data_co_new(:,5)=[];% ɾȥ����������
data_no2_new(:,5)=[];data_an_new(:,5)=[];data_jiujing(:,5)=[];

u=5;  %select one fifth of the data for testing
test_Target=[data_cho_new(1:u:188,:);data_ben_new(1:u:72,:);data_jiaben_new(1:u:66,:);data_co_new(1:u:58,:);data_no2_new(1:u:38,:);data_an_new(1:u:60,:)];
data_cho_new(1:u:size(data_cho_new,1),:)=[]; data_ben_new(1:u:size(data_ben_new,1),:)=[];data_jiaben_new(1:u:size(data_jiaben_new,1),:)=[];
data_co_new(1:u:size(data_co_new,1),:)=[];data_no2_new(1:u:size(data_no2_new,1),:)=[];data_an_new(1:u:size(data_an_new,1),:)=[];

v=2;%dividing the training data into two parts
data_Target=[data_cho_new(1:v:size(data_cho_new,1),:);data_ben_new(1:v:size(data_ben_new,1),:);data_jiaben_new(1:v:size(data_jiaben_new,1),:);data_co_new(1:v:size(data_co_new,1),:);data_no2_new(1:v:size(data_no2_new,1),:);data_an_new(1:v:size(data_an_new,1),:)];
data_cho_new(1:v:size(data_cho_new,1),:)=[]; data_ben_new(1:v:size(data_ben_new,1),:)=[];data_jiaben_new(1:v:size(data_jiaben_new,1),:)=[];
data_co_new(1:v:size(data_co_new,1),:)=[];data_no2_new(1:v:size(data_no2_new,1),:)=[];data_an_new(1:v:size(data_an_new,1),:)=[];

data_S=[data_cho_new;data_ben_new;data_jiaben_new;data_co_new;data_no2_new;data_an_new];

%randomly select w samples per class to find alpha
w=30;
data_S=[rand(w,size(data_cho_new,2)); rand(w,size(data_ben_new,2)); rand(w,size(data_jiaben_new,2)); rand(w,size(data_co_new,2)); rand(w,size(data_no2_new,2)); rand(w,size(data_an_new,2))]; 


total_jiujing=data_jiujing';
data_jiujing=total_jiujing(:,1:2:size(total_jiujing,2));
test_jiujing=total_jiujing(:,2:2:size(total_jiujing,2));

data_S=data_S';
data_Target=data_Target';
test_Target=test_Target';
sensor1=3;
sensor2=4;
sensor3=5;
sensor4=6;
% compute alpha
cal=0;
for C1=-4:1:4
% for C1=-2;
    cal=cal+1;
    C=10.^(C1);
[ H,S,R,Q,IW,B,alpha] = ELM( data_S',data_S',size(data_S,2),'sig',0 ,C);

%% target samples to find T
wucha_Target(size(data_Target,2),1)=0;
for i=1:size(data_Target,2)
    for j=1:size(alpha,1)
    wucha_T(i,j)=(data_Target(:,i)-H'*alpha(:,j))'*(data_Target(:,i)-H'*alpha(:,j));
    wucha_Target(i,:)=wucha_T(i,j)+wucha_Target(i,:);
    end
end
wucha_Target=wucha_Target/size(alpha,1);
%% alcohol samples to find T
wucha_jiujing(size(data_jiujing,2),1)=0;
for i=1:size(data_jiujing,2)
    for j=1:size(alpha,1)
    wucha_jiu(i,j)=(data_jiujing(:,i)-H'*alpha(:,j))'*(data_jiujing(:,i)-H'*alpha(:,j));
    wucha_jiujing(i,:)=wucha_jiu(i,j)+wucha_jiujing(i,:);
    end
end
wucha_jiujing=wucha_jiujing/size(alpha,1);

%% find the optimal T
counter=0;
for T= min(wucha_Target) : 0.0001: 5
    counter=counter+1;
    count_Target= sum(sum(wucha_Target<T));
    count_jiujing=sum(sum(wucha_jiujing>T));
    rate_Target=count_Target/size(data_Target,2);
    rate_jiujing=count_jiujing/size(data_jiujing,2);
    result(counter,1)=T;
    result(counter,2)=rate_Target;
    result(counter,3)=rate_jiujing;
    result(counter,4)=rate_Target+rate_jiujing;
end
[max1,index]=max(result(:,4));
T_MAX=result(index,1)
rate_Target=result(index,2)
rate_jiujing=result(index,3)
rate_total=max1
% figure;
% plot(result(:,1),result(:,2),'-r',result(:,1),result(:,3),'-k')
% legend('target gas','disturbance gas',--1)
% xlabel('T')
% ylabel('Recognition Accuracy')

%% testing target 
T=T_MAX;
wucha1_Target(size(test_Target,2),1)=0;
for i=1:size(test_Target,2)
    for j=1:size(alpha,1)
    wucha_Tar(i,j)=(test_Target(:,i)-H'*alpha(:,j))'*(test_Target(:,i)-H'*alpha(:,j));
    wucha1_Target(i,:)=wucha_Tar(i,j)+wucha1_Target(i,:);
    end
end
wucha1_Target=wucha1_Target/size(alpha,1);
count_Target=sum(sum(wucha1_Target<T));
test_rate_Target=count_Target/size(test_Target,2)
%% testing alcohol
wucha1_jiujing(size(test_jiujing,2),1)=0;
for i=1:size(test_jiujing,2)
    for j=1:size(alpha,1)
    wucha_jiu(i,j)=(test_jiujing(:,i)-H'*alpha(:,j))'*(test_jiujing(:,i)-H'*alpha(:,j));
    wucha1_jiujing(i,:)=wucha_jiu(i,j)+wucha1_jiujing(i,:);
    end
end
wucha1_jiujing=wucha1_jiujing/size(alpha,1);
count_jiujing=sum(sum(wucha1_jiujing>T));
test_rate_jiujing=count_jiujing/size(test_jiujing,2)

    accuracy(cal,1)=C;
    accuracy(cal,2)=test_rate_Target;
    accuracy(cal,3)=test_rate_jiujing;
   accuracy(cal,4)=test_rate_Target+test_rate_jiujing;
end
  [max1,index]=max(accuracy(:,4));
C_MAX=accuracy(index,1)
test_rate_Target=accuracy(index,2)
test_rate_jiujing=accuracy(index,3)
test_rate_total=max1

